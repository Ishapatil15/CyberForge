#!/usr/bin/env python3
import sys

# CyberForge Safe CTF CrackMe Challenge
SECRET_XOR = bytes([x ^ 0x5A for x in b"CyberForgeKey42"])
FLAG_XOR = bytes([x ^ 0x33 for x in b"CTF{str1ngs_and_x0r_r3v3rs1ng_619}"])

def verify(candidate: str):
    cand_bytes = candidate.encode('utf-8')
    obfuscated = bytes([b ^ 0x5A for b in cand_bytes])
    if obfuscated == SECRET_XOR:
        dec_flag = bytes([b ^ 0x33 for b in FLAG_XOR]).decode('utf-8')
        print(f"[+] Access Granted! Flag: {dec_flag}")
        return True
    else:
        print("[-] Access Denied: Invalid passkey.")
        return False

if __name__ == '__main__':
    if len(sys.argv) > 1:
        verify(sys.argv[1])
    else:
        user_input = input("Enter Vault Access Passkey: ")
        verify(user_input)
