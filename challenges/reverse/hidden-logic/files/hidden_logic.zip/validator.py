#!/usr/bin/env python3
import sys

# Hardware license check algorithm
TARGET_ARRAY = [116, 116, 32, 23, 15, 21, 33]
FLAG_ENC = [67, 84, 70, 123, 118, 52, 108, 49, 100, 97, 116, 49, 48, 110, 95, 108, 48, 103, 49, 99, 95, 100, 51, 99, 48, 100, 51, 100, 95, 57, 52, 49, 125]

def validate_license(serial: str) -> bool:
    if len(serial) != len(TARGET_ARRAY):
        return False
    for i, ch in enumerate(serial):
        transformed = (ord(ch) ^ 0x37) + i * 3
        if transformed != TARGET_ARRAY[i]:
            return False
    return True

if __name__ == '__main__':
    inp = sys.argv[1] if len(sys.argv) > 1 else input("Enter Hardware License Serial: ")
    if validate_license(inp):
        print(f"[+] License Validated! Registered Flag: {bytes(FLAG_ENC).decode('utf-8')}")
    else:
        print("[-] Invalid Serial Key.")
